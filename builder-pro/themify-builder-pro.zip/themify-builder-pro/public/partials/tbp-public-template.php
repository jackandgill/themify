<?php

get_header();

do_action( 'tbp_render_the_content' );

get_footer();