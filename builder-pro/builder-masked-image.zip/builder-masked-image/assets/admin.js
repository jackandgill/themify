jQuery(function ($) {
	var cache = [];
	$( 'body' ).on( 'editing_module_option', function ( e, type, settings, context ) {
		if ( type !== 'masked-image' ) {
			return;
		}
		$( '#mask_preset a', context ).click(function() {
			$(this).siblings('.selected').removeClass('selected');
			var val = $( this ).addClass('selected').prop( 'id' );
			
			$( '#mask_image', context ).val( val ).trigger('change').closest( '.tb_field' ).find( '.thumb_preview img' ).prop( 'src', val );
		} );
		setTimeout( function() {
			$( '#mask_icon', context ).change(function() {
				function callback( data, status ) {
					status = !status?'spinhide':'error';
					ThemifyBuilderCommon.showLoader( status );
					var el = $( '#mask_icon_data', context );
					el.val( data );
					Themify.triggerEvent( el[0], 'change' );
				}
				var val = $( this ).val();
				if ( cache[val] !== undefined ) {
					callback( cache[ val ], false );
					return;
				}
				var path = 'https://themify.me/public-api/svg-icons/',
					sub = val.substr( 0, 3 );
				if ( sub === 'ti-' || sub === 'fa-' ) {
					path += ( sub === 'tl-' ? 'themify' : 'fa' ) + '/' + val.substr( 3 ) + '.svg';
				} else {
					callback( '',true );
					return;
				} 
				ThemifyBuilderCommon.showLoader( 'show' );
				$.ajax( {
					url : path,
					dataType: 'text',
					success : function( data ) { 
						callback(data,false);
						cache[val] = data;
					},
					error : function( jqXHR, status, errorThrown ) {
						callback('',true);
					}
				} );
			} );
		}, 100 );
	} );
});