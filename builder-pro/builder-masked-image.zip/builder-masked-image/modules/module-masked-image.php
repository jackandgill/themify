<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Module Name: Image Pro
 * Description: 
 */
class TB_masked_Image_Module extends Themify_Builder_Component_Module {
	function __construct() {
		parent::__construct(array(
			'name' => __( 'Masked Image', 'builder-masked-image' ),
			'slug' => 'masked-image'
		));
	}

	function get_assets() {
		$instance = Builder_Masked_Image::get_instance();
		return array(
			'selector' => '.module.module-masked-image',
			'css' => themify_enque($instance->url.'assets/style.css'),
			'js' => themify_enque($instance->url.'assets/scripts.js'),
			'ver' => $instance->version
		);
	}

	public function get_options() {
		$path = Builder_Masked_Image::get_instance()->url;
		$is_img_enabled = Themify_Builder_Model::is_img_php_disabled();
		$image_sizes = !$is_img_enabled?themify_get_image_sizes_list( false ):array();

		$options = array(
			array(
				'id' => 'mod_title_image',
				'type' => 'text',
				'label' => __( 'Module Title', 'builder-masked-image' ),
				'class' => 'large',
				'render_callback' => array(
					'binding' => 'live',
					'live-selector'=>'.module-title'
				)
			),
			array(
				'type' => 'separator',
				'meta' => array( 'html' => '<hr class="meta_fields_separator" />' )
			),
			array(
				'id' => 'style_image',
				'type' => 'layout',
				'label' => __('Image Alignment', 'builder-masked-image'),
				'mode' => 'sprite',
				'options' => array(
					array('img' => 'image_top', 'value' => 'image-top', 'label' => __('Image Top', 'builder-masked-image')),
					array('img' => 'image_left', 'value' => 'image-left', 'label' => __('Image Left', 'builder-masked-image')),
					array('img' => 'image_right', 'value' => 'image-right', 'label' => __('Image Right', 'builder-masked-image')),
					array('img' => 'image_center', 'value' => 'image-center', 'label' => __('Centered Image', 'builder-masked-image')),
				),
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'url_image',
				'type' => 'image',
				'label' => __( 'Image URL', 'builder-masked-image' ),
				'class' => 'fullwidth',
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'mask_type',
				'type' => 'radio',
				'label' => __( 'Mask Type', 'builder-masked-image' ),
				'options' => array(
					'image' => __( 'Image', 'builder-masked-image' ),
					'icon' => __( 'Icon', 'builder-masked-image' ),
				),
				'default' => 'image',
				'render_callback' => array(
					'binding' => 'live'
				),
				'binding' => array(
					'image' => array(
						'show' => array( 'mask_preset', 'mask_image' ),
						'hide' => array( 'mask_icon' )
					),
					'icon' => array(
						'hide' => array( 'mask_preset', 'mask_image' ),
						'show' => array( 'mask_icon' )
					),
				),
			),
			array(
				'id' => 'mask_preset',
				'type' => 'layout',
				'label' => __('Mask Image', 'builder-masked-image'),
				'mode' => 'sprite',
				'options' => array(
					array('img' => $path . 'assets/presets/badge.svg', 'value' => $path . 'assets/presets/badge.svg', 'label' => __('badge.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/award-badge.svg', 'value' => $path . 'assets/presets/award-badge.svg', 'label' => __('award-badge.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/clover.svg', 'value' => $path . 'assets/presets/clover.svg', 'label' => __('clover.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/comment.svg', 'value' => $path . 'assets/presets/comment.svg', 'label' => __('comment.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/hand.svg', 'value' => $path . 'assets/presets/hand.svg', 'label' => __('hand.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/love.svg', 'value' => $path . 'assets/presets/love.svg', 'label' => __('love.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/paint-splash.svg', 'value' => $path . 'assets/presets/paint-splash.svg', 'label' => __('paint-splash.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/price-tag.svg', 'value' => $path . 'assets/presets/price-tag.svg', 'label' => __('price-tag.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/rocket.svg', 'value' => $path . 'assets/presets/rocket.svg', 'label' => __('rocket.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/sixtagon.svg', 'value' => $path . 'assets/presets/sixtagon.svg', 'label' => __('sixtagon.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/star.svg', 'value' => $path . 'assets/presets/star.svg', 'label' => __('star.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/thumb-up.svg', 'value' => $path . 'assets/presets/thumb-up.svg', 'label' => __('thumb-up.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/tilt-left.svg', 'value' => $path . 'assets/presets/tilt-left.svg', 'label' => __('tilt-left.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/tilt-right.svg', 'value' => $path . 'assets/presets/tilt-right.svg', 'label' => __('tilt-right.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/water-drop.svg', 'value' => $path . 'assets/presets/water-drop.svg', 'label' => __('water-drop.svg', 'builder-masked-image')),
					array('img' => $path . 'assets/presets/wing.svg', 'value' => $path . 'assets/presets/wing.svg', 'label' => __('wing.svg', 'builder-masked-image')),
				),
				'render_callback' => array(
					'binding' => FALSE
				),
			),
			array(
				'id' => 'mask_image',
				'type' => 'image',
				'label' => '&nbsp;',
				'class' => 'fullwidth',
				'render_callback' => array(
					'binding' => 'live'
				),
				'help' => __( 'Use a PNG or SVG image, transparent pixels are treated as mask. Alpha channel is supported.', 'builder-masked-image' ),
			),
			array(
				'id' => 'mask_icon',
				'type' => 'icon',
				'label' => '&nbsp;',
				'class' => 'fullwidth',
				'help' => '',
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'mask_icon_data',
				'type' => 'textarea',
				'label' => '',
				'render_callback' => array(
					'binding' => 'live',
					'event'=>'change'
				)
			),
			array(
				'id' => 'mask_feather',
				'type' => 'text',
				'label' => __('Mask Feather (blur)', 'builder-masked-image'),
				'class' => 'xsmall',
				'help' => 'px',
				'value' => '',
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'mask_flip',
				'type' => 'select',
				'label' =>  __( 'Flip Mask Image', 'builder-masked-image' ),
				'options' => array(
					'none' => __( 'None', 'builder-masked-image' ),
					'horizontal' => __( 'Horizontal', 'builder-masked-image' ),
					'vertical' => __( 'Vertical', 'builder-masked-image' ),
					'both' => __( 'Both', 'builder-masked-image' ),
				),
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'image_size_image',
				'type' => 'select',
				'label' =>  __( 'Image Size', 'builder-masked-image' ),
				'empty' => array(
					'val' => '',
					'label' => ''
				),
				'hide' => !$is_img_enabled,
				'options' => $image_sizes,
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'image_fullwidth_container',
				'type' => 'multi',
				'label' => __('Width', 'builder-masked-image'),
				'fields' => array(
					array(
						'id' => 'width_image',
						'type' => 'text',
						'label' => '',
						'class' => 'xsmall',
						'help' => 'px',
						'value' => '',
						'render_callback' => array(
							'binding' => 'live'
						)
					),
					array(
						'id' => 'auto_fullwidth',
						'type' => 'checkbox',
						'options'=>array(array('name'=>'1','value'=>__('Auto fullwidth image', 'builder-masked-image'))),
						'render_callback' => array(
							'binding' => 'live'
						)
					)
				)
			),
			array(
				'id' => 'height_image',
				'type' => 'text',
				'label' => __('Height', 'builder-masked-image'),
				'class' => 'xsmall',
				'help' => 'px',
				'value' => '',
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'title_image',
				'type' => 'text',
				'label' => __('Image Title', 'builder-masked-image'),
				'class' => 'fullwidth',
				'render_callback' => array(
					'binding' => 'live',
					'live-selector'=>'.image-title'
				)
			),
			array(
				'id' => 'link_image',
				'type' => 'text',
				'label' => __('Image Link', 'builder-masked-image'),
				'class' => 'fullwidth',
				'binding' => array(
					'empty' => array(
						'hide' => array('param_image', 'image_zoom_icon', 'lightbox_size')
					),
					'not_empty' => array(
						'show' => array('param_image', 'image_zoom_icon', 'lightbox_size')
					)
				),
				'render_callback' => array(
					'binding' => 'live'
				)
			),
			array(
				'id' => 'param_image',
				'type' => 'radio',
				'label' => __('Open Link In', 'builder-masked-image'),
				'options' => array(
					'regular' => __('Same window', 'builder-masked-image'),
					'lightbox' => __('Lightbox ', 'builder-masked-image'),
					'newtab' => __('New tab ', 'builder-masked-image')
				),
				'new_line' => false,
				'default' => 'regular',
				'option_js' => true,
				'render_callback' => array(
					'binding' => false
				)
			),
			array(
				'id' => 'lightbox_size',
				'type' => 'multi',
				'label' => __('Lightbox Dimension', 'builder-masked-image'),
				'fields' => array(
					array(
						'id' => 'lightbox_width',
						'type' => 'text',
						'label' => __( 'Width', 'builder-masked-image' ),
						'value' => '',
						'render_callback' => array(
							'binding' => false
						)
					),
					array(
						'id' => 'lightbox_size_unit_width',
						'type' => 'select',
						'label' => __( 'Units', 'builder-masked-image' ),
						'options' => array(
							'pixels' => __('px ', 'builder-masked-image'),
							'percents' => __('%', 'builder-masked-image')
						),
						'default' => 'pixels',
						'render_callback' => array(
							'binding' => false
						)
					),
					array(
						'id' => 'lightbox_height',
						'type' => 'text',
						'label' => __( 'Height', 'builder-masked-image' ),
						'value' => '',
						'render_callback' => array(
							'binding' =>false
						)
					),
					array(
						'id' => 'lightbox_size_unit_height',
						'type' => 'select',
						'label' => __( 'Units', 'builder-masked-image' ),
						'options' => array(
							'pixels' => __('px ', 'builder-masked-image'),
							'percents' => __('%', 'builder-masked-image')
						),
						'default' => 'pixels',
						'render_callback' => array(
							'binding' => false
						)
					)
				),
				'wrap_with_class' => 'tb_group_element tb_group_element_lightbox'
			),
			array(
				'id' => 'caption_image',
				'type' => 'textarea',
				'label' => __('Image Caption', 'builder-masked-image'),
				'class' => 'fullwidth',
				'render_callback' => array(
					'binding' => 'live',
					'live-selector'=>'.image-caption'
				),
				'binding' => array(
					'empty' => array(
						'hide' => array('gutter_group')
					),
					'not_empty' => array(
						'show' => array('gutter_group')
					)
				),
			),
			array(
				'id' => 'gutter_group',
				'type' => 'multi',
				'label' => '&nbsp;',
				'fields' => array(
					array(
						'id' => 'gutter_image',
						'type' => 'text',
						'label' => __('Horizontal Gap', 'builder-masked-image'),
						'class' => 'xsmall',
						'after' => 'px',
						'render_callback' => array(
							'binding' => 'live'
						)
					),
					array(
						'id' => 'gutter_h_image',
						'type' => 'text',
						'label' => __('Vertical Gap', 'builder-masked-image'),
						'class' => 'xsmall',
						'after' => 'px',
						'render_callback' => array(
							'binding' => 'live'
						)
					),
				)
			),
			array(
				'id' => 'alt_image',
				'type' => 'text',
				'label' => __('Image Alt Tag', 'builder-masked-image'),
				'class' => 'fullwidth',
				'render_callback' => array(
					'binding' => false
				)
			),
			// Additional CSS
			array(
				'type' => 'separator',
				'meta' => array( 'html' => '<hr/>')
			),
			array(
				'id' => 'css_image',
				'type' => 'text',
				'label' => __( 'Additional CSS Class', 'builder-masked-image'),
				'class' => 'large exclude-from-reset-field',
				'help' => sprintf( '<br/><small>%s</small>', __( 'Add additional CSS class(es) for custom styling (<a href="https://themify.me/docs/builder#additional-css-class" target="_blank">learn more</a>).', 'builder-masked-image' ) ),
				'render_callback' => array(
					'binding' => 'live'
				)
			)
		);
		return $options;
	}

	public function get_default_settings() {
		$url = Builder_Masked_Image::get_instance()->url;
		return array(
			'url_image' => $url . 'assets/sample-image.jpg',
			'mask_image' => $url. 'assets/presets/badge.svg',
                        'mask_flip'=>'none',
			'width_image' => 350,
			'height_image' => 275,
			'title_image' => esc_html__( 'Image Title', 'builder-masked-image' ),
			'overlay_effect' => 'fadeIn',
			'image_alignment' => 'image_alignment_left'
		);
	}

	public function get_styling() {
		$font_color_selectors = array('.module-masked-image');
        $font_color_id = 'font_color';
        $font_color_label = __('Font Color', 'themify');
        if(method_exists( __CLASS__, 'get_color_type' )){
            $font_color = self::get_color($font_color_selectors, $font_color_id, $font_color_label,'color',true);
        }else{
            $font_color = self::get_color($font_color_selectors, $font_color_id, $font_color_label);
        }
		$general = array(
			// Background
			self::get_seperator('image_bacground', __('Background', 'builder-masked-image'), false),
			self::get_image('.module-masked-image'),
			self::get_color('.module-masked-image', 'background_color', __('Background Color', 'builder-masked-image'), 'background-color'),
			self::get_repeat('.module-masked-image'),
			// Font
			self::get_seperator('font', __('Font', 'builder-masked-image')),
			self::get_font_family(array('.module-masked-image', '.module-masked-image .image-title')),
			! method_exists( __CLASS__, 'get_element_font_weight' ) ? '' : self::get_element_font_weight( array('.module-masked-image', '.module-masked-image .image-title') ),
			! method_exists( __CLASS__, 'get_color_type' ) ? '' : self::get_color_type('font_color_type',__('Font Color Type', 'themify'),'font_color','font_gradient_color'),
            $font_color,
			! method_exists( __CLASS__, 'get_gradient_color' ) ? '' : self::get_gradient_color(array( '.module-masked-image .image-title','.module-masked-image .image-caption' ),'font_gradient_color',__('Font Color', 'themify')),
			self::get_font_size('.module-masked-image'),
			self::get_line_height('.module-masked-image'),
			self::get_letter_spacing('.module-masked-image'),
			self::get_text_align('.module-masked-image'),
			self::get_text_transform('.module-masked-image'),
			self::get_font_style('.module-masked-image'),
                        self::get_text_decoration('.module-masked-image','text_decoration_regular'),
			// Link
			self::get_seperator('link', __('Link', 'builder-masked-image')),
			self::get_color('.module-masked-image a', 'link_color'),
			self::get_color('.module-masked-image a:hover', 'link_color_hover', __('Color Hover', 'builder-masked-image')),
			self::get_text_decoration('.module-masked-image a'),
			// Padding
			self::get_seperator('padding', __('Padding', 'builder-masked-image')),
			self::get_padding('.module-masked-image'),
			// Margin
			self::get_seperator('margin', __('Margin', 'builder-masked-image')),
			self::get_margin('.module-masked-image'),
			// Border
			self::get_seperator('border', __('Border', 'builder-masked-image')),
			self::get_border('.module-masked-image'),
		);

		$image_title = array(
			// Font
			self::get_seperator('font', __('Font', 'builder-masked-image'), false),
			self::get_font_family(array('.module-masked-image .image-title', '.module-masked-image .image-title a'), 'font_family_title'),
			! method_exists( __CLASS__, 'get_element_font_weight' ) ? '' : self::get_element_font_weight( array('.module-masked-image .image-title', '.module-masked-image .image-title a'), 'font_weight_title' ),
			self::get_color(array('.module-masked-image .image-title', '.module-masked-image .image-title a'), 'font_color_title', __('Font Color', 'builder-masked-image')),
			self::get_color(array('.module-masked-image .image-title:hover', '.module-masked-image .image-title a:hover'), 'font_color_title_hover', __('Color Hover', 'builder-masked-image')),
			self::get_font_size('.module-masked-image .image-title', 'font_size_title'),
			self::get_line_height('.module-masked-image .image-title', 'line_height_title'),
			self::get_letter_spacing('.module-masked-image .image-title', 'letter_spacing_title'),
            self::get_text_transform('.module-masked-image .image-title', 'text_transform_title'),
            self::get_font_style('.module-masked-image .image-title', 'font_style_title','font_title_bold'),
			// Padding
			self::get_seperator('padding', __('Padding', 'builder-masked-image')),
			self::get_padding('.module-masked-image .image-title', 'image_title_padding'),
			// Margin
			self::get_seperator('margin', __('Margin', 'builder-masked-image')),
			self::get_margin('.module-masked-image .image-title', 'image_title_margin'),
		);

		$image_caption = array(
			// Font
			self::get_seperator('font', __('Font', 'builder-masked-image'), false),
			self::get_font_family('.module-masked-image .image-caption', 'font_family_caption'),
			! method_exists( __CLASS__, 'get_element_font_weight' ) ? '' : self::get_element_font_weight( '.module-masked-image .image-caption', 'font_weight_caption' ),
			self::get_color('.module-masked-image .image-caption', 'font_color_caption', __('Font Color', 'builder-masked-image')),
			self::get_font_size('.module-masked-image .image-caption', 'font_size_caption'),
			self::get_line_height('.module-masked-image .image-caption', 'line_height_caption'),
            // Padding
            self::get_seperator('padding', __('Padding', 'builder-masked-image')),
            self::get_padding('.module-masked-image .image-caption', 'image_caption_padding'),
            // Margin
            self::get_seperator('margin', __('Margin', 'builder-masked-image')),
            self::get_margin('.module-masked-image .image-caption', 'image_caption_margin'),
		);

		return array(
			array(
				'type' => 'tabs',
				'id' => 'module-styling',
				'tabs' => array(
					'general' => array(
						'label' => __('General', 'builder-masked-image'),
						'fields' => $general
					),
					'module-title' => array(
						'label' => __('Module Title', 'builder-masked-image'),
						'fields' => $this->module_title_custom_style()
					),
					'title' => array(
						'label' => __('Image Title', 'builder-masked-image'),
						'fields' => $image_title
					),
					'caption' => array(
						'label' => __('Image Caption', 'builder-masked-image'),
						'fields' => $image_caption
					)
				)
			)
		);
	}

	protected function _visual_template() {
		$module_args = self::get_module_args();?>

		<# var fullwidth = data.auto_fullwidth == '1' && ( data.style_image == 'image-top' || data.style_image == 'image-center' ) ? 'auto_fullwidth' : ''; #>
		<div class="module module-<?php echo $this->slug; ?> {{ fullwidth }} {{ data.style_image }}">
			<!--insert-->
                        <# if ( data.mod_title_image ) { #>
				<?php echo $module_args['before_title']; ?>{{{ data.mod_title_image }}}<?php echo $module_args['after_title']; ?>
			<# }
			var style='';
			if( ! fullwidth ) {
				style = 'width:' + ( data.width_image ? data.width_image + 'px;' : 'auto;' );
				style += 'height:' + ( data.height_image ? data.height_image + 'px;' : 'auto;' );
			}
			var image = '<img src="'+ data.url_image +'" style="' + style + '"/>',
							mask = data.mask_image;
			if ( data.mask_type == 'icon' && data.mask_icon_data !== '' ) {
				mask = 'data:image/svg+xml;charset=UTF-8,' + data.mask_icon_data;
			}
			#>
			<div class="bmi-image-wrap">
				<div class="bmi-image">
					<a href="{{ data.link_image }}">
						{{{ image }}}
						<canvas data-mask="{{ mask }}" data-gutter="{{ data.gutter_image }}" data-gutter-h="{{ data.gutter_h_image }}" data-transparency="{{ data.transparency_effect }}" data-mask-flip="{{ data.mask_flip }}" data-feather="{{ data.mask_feather }}"></canvas>
					</a>
				</div>
			</div>

			<# if ( data.caption_image || data.title_image ) { #>
			<div class="bmi-text-wrap"><div class="bmi-text"><# if ( data.caption_image || data.title_image ) { #><h3 class="image-title">{{{ data.title_image }}}</h3><# } #><div class="image-caption">{{{ data.caption_image }}}</div></div></div>
			<# } #>
		</div>
	<?php
	}
}

Themify_Builder_Model::register_module( 'TB_masked_Image_Module' );