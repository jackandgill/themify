<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
/**
 * Template FitText
 * 
 * Access original fields: $mod_settings
 * @author Themify
 */
if (TFCache::start_cache($mod_name, self::$post_id, array('ID' => $module_ID))):
    $fields_default = array(
        'fittext_text' => '',
        'fittext_link' => '',
        'fittext_params' => '',
        'font_family' => '',
        'add_css_fittext' => '',
        'js_params' => array(),
        'animation_effect' => ''
    );

    $fields_args = wp_parse_args($mod_settings, $fields_default);
    unset($mod_settings);
    $animation_effect = self::parse_animation_effect($fields_args['animation_effect'], $fields_args);
    $fields_args['fittext_params']  = $fields_args['fittext_params'] !== '' ?array_values( explode( '|', $fields_args['fittext_params'] ) ):array();
    
    $fields_args['fittext_params'] = isset($fields_args['fittext_params'][0])?$fields_args['fittext_params'][0]:false;//convert old checkbox type to radio type
    $container_class = implode(' ', apply_filters('themify_builder_module_classes', array(
        'module', 'module-' . $mod_name, $module_ID, $fields_args['add_css_fittext'], $animation_effect
                    ), $mod_name, $module_ID, $fields_args)
    );

    $link_target = $link_class = false;
    if ($fields_args['fittext_params']==='lightbox') {
        $link_class = 'themify_lightbox';
    } elseif ($fields_args['fittext_params']==='newtab') {
        $link_target = '_blank';
    }

    $container_props = apply_filters('themify_builder_module_container_props', array(
        'id' => $module_ID,
        'class' => $container_class
            ), $fields_args, $mod_name, $module_ID);
    ?>
    <!-- module fittext -->
    <div <?php echo self::get_element_attributes($container_props); ?><?php if($fields_args['font_family']!=='' && $fields_args['font_family']!=='default'):?> data-font-family="<?php echo $fields_args['font_family']; ?>"<?php endif;?>>
        <!--insert-->
        <?php do_action('themify_builder_before_template_content_render'); ?>

        <?php if ('' !== $fields_args['fittext_link']) : ?>
            <a href="<?php echo $fields_args['fittext_link']; ?>"<?php if ($link_class !== false): ?> class="<?php echo $link_class; ?>"<?php endif; ?><?php if ($link_target !== false): ?> target="<?php echo $link_target; ?>"<?php endif; ?>>
            <?php endif; ?>

            <span><?php echo $fields_args['fittext_text']; ?></span>

            <?php if ('' !== $fields_args['fittext_link']) : ?>
            </a>
        <?php endif; ?>

        <?php do_action('themify_builder_after_template_content_render'); ?>
    </div>
    <!-- /module fittext -->
<?php endif; ?>
<?php TFCache::end_cache(); ?>