=== Themify Icons ===
Contributors: themifyme
Tags: icon, font, editor, menu, menu-items, admin
Requires at least: 3.9
Tested up to: 4.9.8
Stable tag: 1.0.5
License: GPLv2 or later

Nifty plugin that enables you to use the Themify Icons (https://themify.me/themify-icons) font on your site.

== Description ==

Insert the Themify Icons easily in your post content, WordPress menus, and widget titles.

== Installation ==

1. Login to your wp-admin > go to Plugins > Add New and upload the plugin zip file
2. Activate the plugin
3. Enjoy!
