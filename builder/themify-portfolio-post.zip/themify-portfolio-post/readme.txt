=== Themify Portfolio Post ===
Contributors: themifyme
Plugin Name: Themify Portfolio Post
Tags: portfolio, post, showcase, post-type
Requires at least: 4.5
Tested up to: 4.9.5
Stable tag: 1.0.8

This plugin will add Portfolio post type.

== Description ==

Themify Portfolio Posts is a simple plugin that allows you to showcase your projects info in a clean layout. Minimal and sleek, you can click on each image of your gallery portfolio and opt to show further details such as the project type, client name, and commission date – or edit each heading and name your own. 

Themify Portfolio Post plugin is compatible with any theme and users can install it on their WordPress admin dashboard like all other plugins.



== Installation ==

1. Upload the whole plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy!

== Changelog ==

The changelog is located at: https://themify.me/changelogs/themify-portfolio-post.txt