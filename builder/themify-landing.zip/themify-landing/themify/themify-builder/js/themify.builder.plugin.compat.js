(function ($) {

    'use strict';

    // this script can be deleted later
})(jQuery);